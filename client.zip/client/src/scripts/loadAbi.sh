#!/usr/bin/env bash

set -e
set -x

cp ../../../smart_contracts/artifacts/contracts/Etherdocs.sol/Etherdocs.json ../lib